function y = delta_eta( x , eta )

y = 1./(pi*eta*(1 + x.^2/(eta^2)));

end

